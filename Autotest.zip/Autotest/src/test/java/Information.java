import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Information {
    public static WebDriver driver;
    @Test
    public void adiInfo() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Админ\\Desktop\\chromedriver_win32\\chromedriver.exe");

        //Test for adiInfo
        driver=new ChromeDriver();
        driver.manage(). window().maximize();
        driver.get("http://users.bugred.ru/user/login/index.html") ;
        driver.findElement(By.xpath("//input[@name='login']")).sendKeys("ann@gmail.com");
        driver.findElement(By.xpath("//div[@class='row']//div[1]//form[1]//table[1]//tbody[1]//tr[2]//td[2]//input[1]")).sendKeys("2701");
        driver.findElement(By.xpath("//div[@class='row']//div[1]/form[1]/table[1]/tbody[1]/tr[3]/td[2]/input[1]")).click();
        driver.findElement(By.xpath("//*[@id=\"fat-menu\"]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"fat-menu\"]/ul/li[1]/a")).click();
        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/form/table/tbody/tr[3]/td[2]/select/option[3]")).click();
        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/form/table/tbody/tr[4]/td[2]/input")).sendKeys("7.01.2020");
        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/form/table/tbody/tr[5]/td[2]/input")).sendKeys("2.01.2021");
        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("fitness");
        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/form/table/tbody/tr[7]/td[2]/input")).sendKeys("34786543278");
        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/form/table/tbody/tr[8]/td[2]/input")).click();



    }
}
