public class random {
}
